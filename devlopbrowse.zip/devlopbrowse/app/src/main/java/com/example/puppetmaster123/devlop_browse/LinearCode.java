package com.example.puppetmaster123.devlop_browse;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class LinearCode extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_linear_code);
    }
}
