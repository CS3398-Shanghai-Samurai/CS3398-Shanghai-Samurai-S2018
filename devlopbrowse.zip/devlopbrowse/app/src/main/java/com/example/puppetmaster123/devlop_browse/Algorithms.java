package com.example.puppetmaster123.devlop_browse;

/**
 * Created by puppetmaster123 on 4/2/2018.
 */

public class Algorithms {
    private String name;
    private String Catagory;

    public Algorithms(String name, String catagory) {
        this.name = name;
        Catagory = catagory;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCatagory() {
        return Catagory;
    }

    public void setCatagory(String catagory) {
        Catagory = catagory;
    }


}


